---
title: certbot白嫖https证书
tags:
  - certbot
  - 证书
categories:
  - 运维
cover: 'http://api.mtyqx.cn/api/random.php?1'
abbrlink: 733eea1c
keywords: certbot白嫖https证书
comments: true
date: 2020-11-26 16:12:33
description:
---

# 1.certbot安装

```
cd /usr/local/src
wget https://dl.eff.org/certbot-auto
chmod a+x certbot-auto
```

# 2.认证方式

```
dns-01：给域名添加一个 DNS TXT 记录。
http-01：在域名对应的 Web 服务器下放置一个 HTTP well-known URL 资源文件。
tls-sni-01：在域名对应的 Web 服务器下放置一个 HTTPS well-known URL 资源文件。
```

# 3. 申请证书

这里`myiszhb.cn` 域名最好加是`xxx.myiszhb.cn`这样才是受信任的

```
./certbot-auto certonly  -d *.myiszhb.cn  --manual --preferred-challenges dns --server https://acme-v02.api.letsencrypt.org/directory 
```

参数简介

```
certonly，表示安装模式，Certbot 有安装模式和验证模式两种类型的插件。
--manual  表示手动安装插件，Certbot 有很多插件，不同的插件都可以申请证书，用户可以根据需要自行选择
-d 为那些主机申请证书，如果是通配符，输入 *.newyingyong.cn（可以替换为你自己的域名）
--preferred-challenges dns，使用 DNS 方式校验域名所有权
--server，Let's Encrypt ACME v2 版本使用的服务器不同于 v1 版本，需要显示指定。
```

# 4.交互界面

```
Saving debug log to /var/log/letsencrypt/letsencrypt.log
Plugins selected: Authenticator manual, Installer None
Enter email address (used for urgent renewal and security notices) (Enter 'c' to
cancel): xxx@163.com

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Please read the Terms of Service at
https://letsencrypt.org/documents/LE-SA-v1.2-November-15-2017.pdf. You must
agree in order to register with the ACME server at
https://acme-v02.api.letsencrypt.org/directory
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
(A)gree/(C)ancel: A

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Would you be willing to share your email address with the Electronic Frontier
Foundation, a founding partner of the Let's Encrypt project and the non-profit
organization that develops Certbot? We'd like to send you email about our work
encrypting the web, EFF news, campaigns, and ways to support digital freedom.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
(Y)es/(N)o: Y

Obtaining a new certificate
Performing the following challenges:
dns-01 challenge for archerwong.cn

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
NOTE: The IP of this machine will be publicly logged as having requested this
certificate. If you're running certbot in manual mode on a machine that is not
your server, please ensure you're okay with that.

Are you OK with your IP being logged?
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
(Y)es/(N)o: (Y)es/(N)o: Y

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Please deploy a DNS TXT record under the name
_acme-challenge.myiszhb.cn with the following value:

UCSGGMLKXQ7BKZ3XOb-wLUM8yvEI4BGt-86waMxnJJ3

Before continuing, verify the record is deployed.
- - - - - - - - - - - - - - - - -
```



自此证书就申请完毕了

如需自动续费参考：https://www.cnblogs.com/redirect/p/10140254.html