---
title: 什么是变量、常量、作用域、final关键字以及变量的命名规范
tags:
  - 变量
  - 常量
categories:
  - Java
  - se
cover: 'http://api.mtyqx.cn/api/random.php?5'
comments: true
abbrlink: c278e9dc
keywords: 什么是变量、常量、作用域、final关键字以及变量的命名规范
description: 什么是变量、常量、作用域、final关键字以及变量的命名规范
date: 2020-11-30 20:00:53
---
# 变量
1. 变量是什么：就是可以变化的数据!
2. Java是一种强类型语言，每个变量都必须声明其类型。
3. Java变量是程序中最基本的存储单元，其要素包括变量名，变量类型和作用域。

```java
String userName = "张三"；
//String 是数据类型
//userName 是变量名
//张三 是值
```

`注意`
- `每个变量都必须有类型，类型可以是基本类型，也可以是引用类型`。
- `变量名必须是合法的标识符`。
- `变量声明是一个完整的语句，因此每一个声明都必须以分号结束`。

## 变量作用域

- 类变量（也可以叫做成员变量。使用static修饰）
- 实例变量
- 局部变量（写在方法里的）
- Java中有一个很重要的原则：就近原则，那个就访问那个

```java
public class Test{
    //这个是类变量
    static int num = 0;
    //这个是实例变量
    String str = "张三";
    int i = 1000;
    
    public void method(){
        //这个是局部变量
        int i = 0;
        //这里i=0，这里就是Java中的就近原则
        System.out.println(i);
        //c变量赋值100，a、b只声明了没有赋值
        int a,b,c = 100;
        //这样每个都赋值了。
        int d=10，e=10,f=10;
        
    }
}
```

# 常量

1. 常量是初始化后不能再改变值!不会变动的值。
2. 所谓常量可以理解成一种特殊的变量，它的值背设定后，在程序运行过程中不允许改变。
3. 常量名一般用大写。
4. 常量使用final关键字修饰

```java
public class Test{
    //NUM就是常量 但是要使用final关键字修饰
    final double NUM = 2500;
}
```

# 变量的命名规范

1. 所有变量、方法、类名要==见名如意==
2. 类成员变量：首字母小写和驼峰原则：monthSalary
3. 局部变量：首字母小写和驼峰原则
4. 常量：首字母大写和下划线：MAX_VALUE
5. 类名：首字母大写和驼峰原则：Man，GoodMan
6. 方法名：首字母小写和驼峰原则：run(),runRun()

# final关键字

1. final是Java语言中的一个关键字。
2. final表示最终的，不可变的。
3. final可以修饰变量以及方法，还有类等。
4. final修饰的变量？   
final修饰的变量，只能赋一次值，不允许被重新赋值。
5. final修饰的方法？  
final修饰的方法无法被覆盖，被重写。
6. final修饰的类？  
final修饰的类无法被继承
7. final控制不了能不能被调用的问题。final管的是啥？  
final修饰的表示最后的，不能变得，不能改的。
8. final修饰的引用会怎么样呢？  
final修饰的引用只能指向一个对象，不能被修改
9. final修饰的实例变量，系统不会赋默认值，必须手动赋值。

```java
class C{
    private String name;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
public  class Test {
    public static void main(String[]agrs){
    //final修饰的引用只能指向一个对象 ，但是被new出来的对象在堆中是可以被修改的
        final C c =new C();
        c.setName("张三");
        System.out.println(c.getName());
        c.setName("王五");
        System.out.println(c.getName());
    }
}

```
结果：
```java
张三
王五
```

## 关于final赋值问题

```java
class User{
    //Java默认不会给final赋默认值
    final double i;
    //如果不在构造方法里赋值，程序启动报错
    public User(){
        this.i=80;
    }
}
```