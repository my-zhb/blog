---
title: Java数据类型
tags:
  - 数据类型
categories:
  - Java
  - se
cover: 'http://api.mtyqx.cn/api/random.php?3'
abbrlink: 3daa4bf4
keywords: Java数据类型
description: Java数据类型
date: 2020-11-28 19:25:53
comments: true
---

# Java数据类型

| 类型   | 描述                                                     |
| ------ | :------------------------------------------------------:|
| byte |    基本数据类型-整数类型-占1个字节                        |
| short |   基本数据类型-整数类型-占2个字节                        |
| int  |    基本数据类型-整数类型-占4个字节                        |
| long |    基本数据类型-整数类型-占8个字节                        |
| float | 基本数据类型-浮点类型-占4个字节                          |
| double |  基本数据类型-浮点类型-占8个字节                       |
| char |    基本数据类型-字符类型-占2个字节                        |
| blooean | 基本数据类型-boolean类型-占1个位其值只有true和false    |
| calss |  	引用数据类型-类                                      |
| interface |     引用数据类型-接口                                |
| 数组 |      引用数据类型-数组                                     |

#  什么是字节

1. 位(bit)：是计算机内部数据储存的最小单位,11001100是一个八位二进制

2. 字节(byte)：是计算机中数据处理的基本单位,习惯上用大写B来表示,1B(byte,字节)=8bit(位)

3. 字符：是指计算机中使用的字母、数字、字和符号

4. 示例：

	​	1bit表示1位

	​	1Byte表示一个字节1B=8b

	​	1024B=1KB

	​	1024KB=1M

	​	1024M=1G

# 类型转换

## 强制类型转换

1. `(转换类型)变量名`

2. `有高到低转换`

```java
	public class Test{
	    public static void main(String[] args){
	        int i = 128;
	        //强制转换
	        byte b = (byte)i;
	        //输出结果：-128,为什么会输出-128呢?
	        //因为byte最大值为127,内存溢出了
	        System.out.println(b);
	    }
	}
```

## 自动转换

1. `有低到高转换`

	`注意点`：

	1. `不能对布尔值进行转换`
	2. `不能把对象类型转换成不相干的类型`
	3. `在把高容量转换到低容量的时候，强制转换`
	4. `转换的时候可能存在内存溢出或者精度丢失问题`

```java
	public class Test{
	    public static void main(String[] args){
	        int i = 128;
	        //字段转换
	        double b = i;
	        //输出结果：128.0
	        //因为转成double类型了
	        System.out.println(b);
	    }
	}
```

## 内存溢出问题

1. `操作比较大的数的时候，注意溢出问`

2. `JDK7新特性,数字之间可以用下划线分割表示`

  ```java
  public class Test{
      public static void main(String[] args){
          int money = 10_0000_0000;
          int years = 20;
          int total = money * years;
          //输出结果：-1474836480
          //因为值已经溢出了
          System.out.println(total);
          
          long total2 = money * years;
          
           //输出结果：-1474836480
          //因为money和years默认为int类型,这里已经出现问题,所以它们相乘也是一个int类型的数字
          System.out.println(total2);
          
          long total3 = money * ((long)years);
          //输出结果：200_0000_0000
          System.out.println(total3);
      }
  }
  ```

# 数据类型拓展

## 整数拓展

`进制 二进制(0b开头) 十进制 八进制(0) 十六进制(0x)`

```java
public class Test{
    public static void main(String[] args){
        int i = 10;
        int i2 = 010; //八进制0(逢10进8)
        int i3 = 0x10; //十六进制0x 0~9 A~F 16(逢16进10)
        System.out.println(i);//输出结果10
        System.out.println(i2);//输出结果8
        System.out.println(i3);//输出结果16
    }
}
```
##  浮点数拓展

`浮点数是有舍入误差的,接近但是不等于`

```java
public class Test{
    public static void main(String[] args){
        float f = 0.1f;
        double d = 0.1;
        System.out.println(f==d);//输出false,f不等于d
        
        float f1 = 214121231f;
        float f2 = f1+1;
        System.out.println(f1==f2);//输出true
    }
}
```

## 字符拓展

`所有的字符本质都是数字`

```java
public class Test{
    public static void main(String[] args){
        char c1 = 'A';
        char c2 = '中';
        System.out.println(c1);//输出结果：A
        //(int)c1 强制转换
        System.out.println((int)c1);//输出结果：65
        System.out.println(c2);//输出结果：中
        System.out.println((int)c2);//输出结果：20013
    }
}
```