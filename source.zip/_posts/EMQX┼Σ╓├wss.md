---
title: EMQX配置wss
tags:
  - emqx
categories:
  - 运维
keywords: emq
abbrlink: a464dc8f
comments: true
cover: 
toc: true
date: 2020-11-27 20:07:43
---
# MQTT协议介绍

MQTT（Message Queuing Telemetry Transport，消息队列遥测传输协议），是一种基于发布/订阅（publish/subscribe）模式的"轻量级"通讯协议，该协议构建于TCP/IP协议上，由IBM在1999年发布。MQTT最大优点在于，可以以极少的代码和有限的带宽，为连接远程设备提供实时可靠的消息服务。作为一种低开销、低带宽占用的即时通讯协议，使其在物联网、小型设备、移动应用等方面有较广泛的应用。

MQTT是一个基于客户端-服务器的消息发布/订阅传输协议。MQTT协议是轻量、简单、开放和易于实现的，这些特点使它适用范围非常广泛。在很多情况下，包括受限的环境中，如：机器与机器（M2M）通信和物联网（IoT）。其在，通过卫星链路通信传感器、偶尔拨号的医疗设备、智能家居、及一些小型化设备中已广泛使用


此处跳过安装过程！！

# 1. emqx.conf

emqx.conf 默认是在 /etc/ 目录下的

emqx.conf就修改`listener.wss.external.keyfile`,`listener.wss.external.certfile` 其他默认保存就可以了

```
## Path to the file containing the user's private PEM-encoded key.
##
## See: listener.ssl.$name.keyfile
##
## Value: File
# 此处修改自己证书密钥的路径
listener.wss.external.keyfile = /etc/emqx/certs/key.pem
## Path to a file containing the user certificate.
##
## See: listener.ssl.$name.certfile
##
## Value: File
# 此处修改自己证书的路径
listener.wss.external.certfile = /etc/emqx/certs/cert.pem
```

证书申请可以参考：[certbot白嫖https证书](https://blog.myiszhb.cn/2020/11/26/733eea1c.html)

# 2. 重启

```
systemctl restart emqx
```

# 3. 测试

emqx 默认地址是ip:18083
emqx 默认账号: admin 密码:public

这是ws的

![@VB5UN8R03T(~3LC40}YH}P](https://cdn.jsdelivr.net/gh/my-zhb/CDN/img/20201127144042.png)

这是wss的

![](https://cdn.jsdelivr.net/gh/my-zhb/CDN/img/20201127144132.png)



自此emqx的wss就完成了