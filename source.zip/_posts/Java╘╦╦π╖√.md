---
title: Java运算符
tags:
  - 运算符
categories:
  - Java
  - se
cover: 'http://api.mtyqx.cn/api/random.php?4'
abbrlink: 778179f
keywords: Java运算符
description: Java运算符
date: 2020-11-29 13:39:11
comments: true
---
# Java语言支持如下运算符
- 算术运算符：+、-、*、/、%、++、--
- 赋值运算符：=
- 关系运算符：>、<、>=、<=、==、!=instanceof
- 逻辑运算符：&&、||、!、&、|
- 位运算符：&、|、^、~、>>、<<、>>>
- 条件运算符:?、:
- 扩展赋值运算符:+=、-=、*=、/=、%=


# 算术运算符
```java
public class Test{
    public static void main(String[]args){
        int a = 10;
        int b = 21;
        int c = 25;
        int d = 25;
        
        1.加号运算
        System.out.println(a+b);
        
        2.减号运算
        System.out.println((a-b);
        
        3.乘法运算
        System.out.println(a*b);
        
        4.除法运算
        //这里输出结果为：0 
        //为什么会是0，因为10/25 结果为0.5，int类型就转成0了
        System.out.println(a/b);
        
        5.%（取余）
        //输出结果：1
        //因为21/10 等于 2.1 余数为：1
        System.out.println(b%a);
        
        //输出结果：0
        //25/25 等于 1.0 余数为：0
        System.out.println(c%d);
        
        //输出结果：10
        //10/21 等于 0.476... 不满足1，返回a
        System.out.println(a%b);
        
        6.++，--(一元运算符)
        int a = 3;
		int b = a++;//理解a++,表示这行代码执行后，先给b赋值，然后下次在+1
		int c = a--;//理解a--,表示这行代码执行后，先给b赋值，然后下次在-1
		int d = ++a;//理解++a,表示这行代码执行前，先+1，在给c赋值
		int f = --a;//理解--a,表示这行代码执行前，先-1，在给f赋值
		System.out.println(a);//3
		System.out.println(b);//3
		System.out.println(c);//4
		System.out.println(d);//4
		System.out.println(f);//3
		
        
        //自动升型
        //混合运算返回的结果类型是当前参与运算的最大类型
        //如果是（byte，char，short）类型进行混合运算 Java内部会自动转换成int类型
        long a1 = 123123123123L;
        int b1 = 123;
        short c1 = 10;
        byte d1 = 8;
        System.out.println(a1+b1+c1+d1);//输出结果为Long类型
        System.out.println(b1+c1+d1);//输出结果为int类型
        System.out.println(c1+d1);//输出结果为int类型
    }
}
```

# 逻辑运算符
- & 逻辑与运算：两个变量都为真，结果才为true
- | 逻辑或运算：两个变量有一个为真，结果就为true
```java
public class Test{
    public static void main(String[]args){
        boolean a = true;
        boolean b = false;
        
        //输出结果：false
        //逻辑与运算：两个变量都为真，结果才为true
        System.out.println((a&b));
        //输出结果：true
        //逻辑或运算：两个变量有一个为真，结果就为true
        System.out.println((a|b));
        //输出结果：true
        //如果是真，则变为假，如果为假真变为真
        System.out.println(!(a&b))
    }
}
```

# 短路运算 如下:
什么是短路与现（&&）象：右边表达式不执行，这种现象叫做短路现象。  
什么是短路或现（||）象：当左边表达式为true的时候，后面的就不执行了，否则一直执行  
从效率上来说短路运算符不逻辑运算符效率要高，因为逻辑运算符每个条件都会判断。
```java
  
    int x = 10;
    int y = 11;
    //& 逻辑与 
    System.out.println(x>y & x>y++);
    //这里输出12，为什么呢，& 逻辑与 x>y=false 判断完成之后又执行了x>y++,s所以这里输出12
    System.out.println(y);
    //&& 短路与
    System.out.println(x>y && x>y++);
    //这里输出11，为什么呢，& 逻辑与 x>y=false 判断完第一个为false，直接结束
    System.out.println(y);
    
    //| 逻辑或 
    System.out.println(x>y | x>y++);//结果false
    //这里输出12，为什么呢，| 逻辑或  x>y=false，执行x>y++=false，它会全部执行完只要有一个true就为true
    System.out.println(y);
    //|| 逻辑或
    System.out.println(x>y || x>y++);//false
    //这里输出12，为什么呢，|| 逻辑或  x>y=false,不满足条件 他会继续执行。
    System.out.println(y);
    
    
    System.out.println(x<y || x>y++);//true
    //这里输出11，为什么呢，|| 逻辑或 x<y=true,后面的判断不执行。
    System.out.println(y);
    
```

# 位运算符
```java
    A = 0011 1100
    B = 0000 1101
          
    1.A&B（A和B） 结果：0000 1100 （根据位运算）
    （A的第一位是0，B的第一位是0，结果为0）
    （A的第二位是0，B的第二位是0，结果为0）
    （A的第三位是1，B的第三位是0，结果为0）
    （A的第四位是1，B的第四位是0，结果为0）
    （A的第五位是1，B的第五位是1，结果为1）以此类推
          
    2.A|B（A或者B） 结果：00111101
    解释：只要A和B的进行比较只要有1那么值就为1
         
    3.A^B（亦或）结果：0011 0001
    解释：只要A和B的进行比较只要相同就为0，不相同为1
        
    4.~B（取反） 结果：1111 0010
    解释：B的值为0就取1，为1就取0    
    
    5.<<(左移) *2
    0000 0000  0
    0000 0001  1
    0000 0010  2
    0000 0011  3
    0000 0100  4
    0000 1000  8
    0001 0000  16
    0010 0000  32
    0100 0000  64
    1000 0000  128
    例如：2<<3 
    0000 0010 （2进制 逢2进10）其中1相左移3格就变成 0001 0000 （这个二进制在转换成十进制就是16）
    二进制转十进制如下: 
    0001 0000 
    最后一位开始：0乘2的0次方为：0
    最后二位开始：0乘2的1次方为：0
    最后五位开始：1乘2的4次方为：16
    
    6.>>(右移) /2
    例如：128>>5
    1000 0000 相右边移动五位 即：0000 1000 （转换成十进制可得：8）
    
```

# 条件运算符（三目运算符）
```java
public class Test{
    public static void main(String[] args){
        int a = 10;
        System.out.println(a=10?"等于10":"不等于10")
    }
}
```

# 扩展赋值运算符
```java
public class Test{
    public static void main(String[] args){
        int a = 10;
        int b = 20;
        
        1.+=
        a+=b;(可以理解为：a=a+b);
        
        2.-=
        a-=b;(可以理解为：a=a-b);
        //输出结果：1020
        //因为前面出现字符串默认从 字符串“10”+“20”
        System.out.println(""+a+b);
        
        //输出结果：30
        //因为这个是先运算a+b=30，然后在进行的拼接变成了字符串“30”
        System.out.println(a+b+"");
    }
}
```

# 问题：x+=10 和 x=x+10 一样吗？
```java
//结论：不一样

byte x = 10;
x = x+10; //这里编译出错 不兼容的类型，int无法转成byte，
x+=10;//这里可以 等同于  x = (byte)(x+10);
```